import { Component, OnInit } from '@angular/core';
import { inject } from '@angular/core'; // chama o método de uma biblioteca
import { UsuarioService } from '../services/usuarios.service';
import { Usuarios } from '../models/usuario.model';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-lista-usuarios', // vai chamar esse nome no app.html
  imports: [CommonModule],
  templateUrl: './lista-usuarios.html',
  styleUrl: './lista-usuarios.css',
})
export class ListaUsuarios implements OnInit { //Dá erro se não cirar o método OnInit
  private service = inject(UsuarioService);

  listaUsuarios: Usuarios[] = [];

  ngOnInit(): void {
    this.service.getUsuarios().subscribe(lista => {
      this.listaUsuarios = lista;
    })




  }



}
