import { HttpClient } from "@angular/common/http"; // Biblioteca com os método HTTP
import { Injectable, inject } from "@angular/core"; // Injectable indica que tá trabalhando com tal biblioteca
import { Usuarios } from "../models/usuario.model"; // importa o Model de usuario.
import { Observable} from "rxjs"; // Devolve o retorno do método usado pelo componente
import { catchError } from "rxjs"; // Pega o erro caso ocorra
import { throwError } from "rxjs"; // Devolve o erro

// Inject serve para instanciar uma biblioteca e chamar os objetos dela

@Injectable({ providedIn: "root"}) // Indica que tá trabalhando com HTTP CLIENT

export class UsuarioService { 
    private http = inject(HttpClient); // onde entram os métodos http client

    getUsuarios(): Observable<Usuarios[]> { // Devolve o retorno do método usado pelo componente // Lista de Usuarios! precisa colchete
        return this.http.get<Usuarios[]>('https://jsonplaceholder.typicode.com/users').pipe(
            catchError(err => {
                console.log("Erro ao buscar Usuários: ", err); // Mensagem pra nós desenvolvedores vermos!
                return throwError(() => new Error("Falha ao buscar usuário")) // Mensagem que aparece pro cliente!
            })
        ) 
        // Get será convertido para essa lista de Usuarios. // Passando URL // pipe fará o tratamento de erro


    } 

    postUsuarios() { // Não vamos fazer isso hoje

    }

    deleteUsuarios() { // Não vamos fazer isso hoje(exemplo)

    }

}