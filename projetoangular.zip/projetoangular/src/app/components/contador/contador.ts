import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-contador',
  imports: [CommonModule],
  templateUrl: './contador.html',
  styleUrl: './contador.css',
})

export class Contador {

  nomes: String[] = ["Spinelli", "Vegetti", "Léo Jardim", "Ayrton Senna"];

  valor: number = 0;

  somar(): void{
    this.valor++;
  }

  subtrair(): void{
    this.valor--;
  }

  resetar(): void {
    this.valor = 0;
  }

}